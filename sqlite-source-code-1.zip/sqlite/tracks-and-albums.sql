SELECT TrackId, Name, Title FROM Track INNER JOIN Album ON Track.AlbumId = Album.AlbumId;
